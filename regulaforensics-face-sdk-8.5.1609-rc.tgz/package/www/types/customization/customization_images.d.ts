export class CustomizationImages {
    set onboardingScreenCloseButton(val: string)
    set onboardingScreenIllumination(val: string)
    set onboardingScreenAccessories(val: string)
    set onboardingScreenCameraLevel(val: string)
    set cameraScreenCloseButton(val: string)
    set cameraScreenLightOnButton(val: string)
    set cameraScreenLightOffButton(val: string)
    set cameraScreenSwitchButton(val: string)
    set retryScreenCloseButton(val: string)
    set retryScreenHintEnvironment(val: string)
    set retryScreenHintSubject(val: string)
    set retryScreenHintGeo(val: string)
    set retryScreenHintBadSelfieQuality(val: string)
    set retryScreenHintCleanLens(val: string)
    set retryScreenHintAddIllumination(val: string)
    set retryScreenHintChangeBackground(val: string)
    set retryScreenHintFaceOcclusions(val: string)
    set retryScreenHintCovering(val: string)
    set retryScreenHintRejectMultipleFaces(val: string)
    set processingScreenCloseButton(val: string)
    set successScreenImage(val: string)

    /** 
     * Allows you to deserialize object. 
     */
    static fromJson(jsonObject: Record<string, string>): CustomizationImages
    /** 
     * Allows you to serialize object. 
     */
    toJson(): Record<string, string>
}