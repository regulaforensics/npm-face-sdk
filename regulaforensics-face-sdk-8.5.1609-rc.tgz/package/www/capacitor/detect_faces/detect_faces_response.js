import { DetectFaceResult } from './detect_face_result'
import { DetectFacesException } from './detect_faces_exception'

export class DetectFacesResponse {
    detection
    scenario
    transactionId
    error
    allDetections

    static fromJson(jsonObject) {
        if (jsonObject == null) return null
        const result = new DetectFacesResponse()

        result.detection = DetectFaceResult.fromJson(jsonObject["detection"])
        result.scenario = jsonObject["scenario"]
        result.transactionId = jsonObject["transactionId"]
        result.error = DetectFacesException.fromJson(jsonObject["error"])
        result.allDetections = []
        if (jsonObject["allDetections"] != null)
            for (const item of jsonObject["allDetections"])
                result.allDetections.push(DetectFaceResult.fromJson(item))

        return result
    }

    toJson() {
        return {
            "detection": this.detection?.toJson(),
            "allDetections": this.allDetections?.map(e => e.toJson()),
            "scenario": this.scenario,
            "transactionId": this.transactionId,
            "error": this.error?.toJson(),
        }
    }
}