export class MatchFacesImage {
    image
    imageType
    detectAll
    identifier

    constructor(image, imageType, options) {
        this.image = image
        this.imageType = imageType
        this.detectAll = options?.detectAll ?? false
        this.identifier = ""
    }

    static fromJson(jsonObject) {
        if (jsonObject == null) return null
        const result = new MatchFacesImage()

        result.image = jsonObject["image"]
        result.imageType = jsonObject["imageType"]
        result.detectAll = jsonObject["detectAll"]
        result.identifier = jsonObject["identifier"]

        return result
    }

    toJson() {
        return {
            "image": this.image,
            "imageType": this.imageType,
            "detectAll": this.detectAll,
            "identifier": this.identifier,
        }
    }
}