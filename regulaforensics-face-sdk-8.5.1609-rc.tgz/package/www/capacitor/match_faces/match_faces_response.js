import { ComparedFacesPair } from './compared_faces_pair'
import { MatchFacesDetection } from './match_faces_detection'
import { MatchFacesException } from './match_faces_exception'

export class MatchFacesResponse {
    results
    detections
    tag
    transactionId
    error

    static fromJson(jsonObject) {
        if (jsonObject == null) return null
        const result = new MatchFacesResponse()

        result.results = []
        if (jsonObject["results"] != null)
            for (const item of jsonObject["results"])
                result.results.push(ComparedFacesPair.fromJson(item))
        result.detections = []
        if (jsonObject["detections"] != null)
            for (const item of jsonObject["detections"])
                result.detections.push(MatchFacesDetection.fromJson(item))
        result.tag = jsonObject["tag"]
        result.transactionId = jsonObject["transactionId"]
        result.error = MatchFacesException.fromJson(jsonObject["error"])

        return result
    }

    toJson() {
        return {
            "results": this.results?.map(e => e.toJson()),
            "detections": this.detections?.map(e => e.toJson()),
            "tag": this.tag,
            "transactionId": this.transactionId,
            "error": this.error?.toJson(),
        }
    }
}