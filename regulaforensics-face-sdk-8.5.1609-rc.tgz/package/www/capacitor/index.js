import {
    exec,
    serializeInterface,
    _setVideoEncoderCompletion,
    _setLivenessNotificationCompletion,
    _setCameraSwitchCallback,
} from './internal/bridge'

import { CameraPosition } from './customization/camera_position'
import { CustomizationColors } from './customization/customization_colors'
import { CustomizationFonts } from './customization/customization_fonts'
import { CustomizationImages } from './customization/customization_images'
import { Customization } from './customization/customization'
import { Font, FontStyle } from './customization/font'
import { ScreenOrientation } from './customization/screen_orientation'
export {
    CameraPosition,
    CustomizationColors,
    CustomizationFonts,
    CustomizationImages,
    Customization,
    Font,
    FontStyle,
    ScreenOrientation,
}

import { FaceSDKVersion } from './init/face_sdk_version'
import { InitConfig } from './init/init_config'
import { InitException } from './init/init_exception'
import { InitErrorCode } from './init/init_exception'
import { LicenseException } from './init/license_exception'
import { LicensingResultCode } from './init/license_exception'
export {
    FaceSDKVersion,
    InitConfig,
    InitException,
    InitErrorCode,
    LicenseException,
    LicensingResultCode,
}

import { DetectFaceResult } from './detect_faces/detect_face_result'
import { DetectFacesAttributeResult } from './detect_faces/detect_faces_attribute_result'
import { DetectFacesAttribute } from './detect_faces/detect_faces_attribute'
import { DetectFacesBackendException, DetectFacesBackendErrorCode } from './detect_faces/detect_faces_backend_exception'
import { DetectFacesConfig } from './detect_faces/detect_faces_config'
import { DetectFacesException, DetectFacesErrorCode } from './detect_faces/detect_faces_exception'
import { DetectFacesRequest } from './detect_faces/detect_faces_request'
import { DetectFacesResponse } from './detect_faces/detect_faces_response'
import { DetectFacesScenario } from './detect_faces/detect_faces_scenario'
export {
    DetectFaceResult,
    DetectFacesAttributeResult,
    DetectFacesAttribute,
    DetectFacesBackendException,
    DetectFacesBackendErrorCode,
    DetectFacesConfig,
    DetectFacesException,
    DetectFacesErrorCode,
    DetectFacesRequest,
    DetectFacesResponse,
    DetectFacesScenario,
}

import { FaceCaptureConfig } from './face_capture/face_capture_config'
import { FaceCaptureException, FaceCaptureErrorCode } from './face_capture/face_capture_exception'
import { FaceCaptureImage, ImageType } from './face_capture/face_capture_image'
import { FaceCaptureResponse } from './face_capture/face_capture_response'
export {
    FaceCaptureConfig,
    FaceCaptureException,
    FaceCaptureErrorCode,
    FaceCaptureImage,
    ImageType,
    FaceCaptureResponse,
}

import { OutputImageCrop, OutputImageCropAspectRatio } from './image_params/output_image_crop'
import { OutputImageParams } from './image_params/output_image_params'
import { Point } from './image_params/point'
import { Rect } from './image_params/rect'
import { Size } from './image_params/size'
export {
    OutputImageCrop,
    OutputImageCropAspectRatio,
    OutputImageParams,
    Point,
    Rect,
    Size,
}

import { ImageQualityCharacteristicName } from './image_quality/image_quality_characteristic_name'
import { ImageQualityCharacteristic } from './image_quality/image_quality_characteristic'
import { ImageQualityGroup } from './image_quality/image_quality_group'
import { ImageQualityRange } from './image_quality/image_quality_range'
import { ImageQualityResult, ImageQualityGroupName, ImageQualityResultStatus } from './image_quality/image_quality_result'
export {
    ImageQualityCharacteristicName,
    ImageQualityCharacteristic,
    ImageQualityGroup,
    ImageQualityRange,
    ImageQualityResult,
    ImageQualityGroupName,
    ImageQualityResultStatus,
}

import { LivenessConfig, RecordingProcess, LivenessType, LivenessSkipStep } from './liveness/liveness_config'
import { EnrollmentConfig } from './liveness/enrollment_config'
import { VerificationConfig } from './liveness/verification_config'
import { LivenessBackendException, LivenessBackendErrorCode } from './liveness/liveness_backend_exception'
import { LivenessException, LivenessErrorCode } from './liveness/liveness_exception'
import { LivenessResponse, LivenessStatus } from './liveness/liveness_response'
import { LivenessNotification, LivenessProcessStatus } from './liveness/liveness_notification'
import { EnrollmentResponse } from './liveness/enrollment_response'
import { VerificationMatchResponse } from './liveness/verification_match_response'
import { VerificationResponse } from './liveness/verification_response'
export {
    LivenessBackendException,
    LivenessBackendErrorCode,
    LivenessConfig,
    RecordingProcess,
    LivenessType,
    LivenessSkipStep,
    LivenessException,
    LivenessErrorCode,
    LivenessNotification,
    LivenessProcessStatus,
    LivenessResponse,
    LivenessStatus,
    EnrollmentConfig,
    VerificationConfig,
    EnrollmentResponse,
    VerificationMatchResponse,
    VerificationResponse,
}

import { ComparedFace } from './match_faces/compared_face'
import { ComparedFacesPair } from './match_faces/compared_faces_pair'
import { ComparedFacesSplit } from './match_faces/compared_faces_split'
import { MatchFacesBackendException } from './match_faces/match_faces_backend_exception'
import { MatchFacesConfig, ProcessingMode } from './match_faces/match_faces_config'
import { MatchFacesDetectionFace } from './match_faces/match_faces_detection_face'
import { MatchFacesDetection } from './match_faces/match_faces_detection'
import { MatchFacesException, MatchFacesErrorCode } from './match_faces/match_faces_exception'
import { MatchFacesImage } from './match_faces/match_faces_image'
import { MatchFacesRequest } from './match_faces/match_faces_request'
import { MatchFacesResponse } from './match_faces/match_faces_response'
export {
    ComparedFace,
    ComparedFacesPair,
    ComparedFacesSplit,
    MatchFacesBackendException,
    MatchFacesConfig,
    ProcessingMode,
    MatchFacesDetectionFace,
    MatchFacesDetection,
    MatchFacesException,
    MatchFacesErrorCode,
    MatchFacesImage,
    MatchFacesRequest,
    MatchFacesResponse,
}

import { EditGroupPersonsRequest } from './person_database/edit_group_persons_request'
import { ImageUpload } from './person_database/image_upload'
import { PageableItemList } from './person_database/pageable_item_list'
import { PersonDatabase } from './person_database/person_database'
import { PersonGroup } from './person_database/person_group'
import { PersonImage } from './person_database/person_image'
import { Person } from './person_database/person'
import { SearchPersonDetection } from './person_database/search_person_detection'
import { SearchPersonImage } from './person_database/search_person_image'
import { SearchPersonRequest } from './person_database/search_person_request'
import { SearchPersonFilter } from './person_database/search_person_filter'
import { SearchPerson } from './person_database/search_person'
export {
    EditGroupPersonsRequest,
    ImageUpload,
    PageableItemList,
    PersonDatabase,
    PersonGroup,
    PersonImage,
    Person,
    SearchPersonDetection,
    SearchPersonImage,
    SearchPersonRequest,
    SearchPersonFilter,
    SearchPerson,
}


export class FaceSDK {
    static get instance() { return FaceSDK._instance }
    static _instance = new FaceSDK()

    get version() { return this._version }
    _version

    get serviceUrl() { return this._serviceUrl }
    _serviceUrl
    set serviceUrl(val) {
        this._serviceUrl = val
        this._setServiceUrl(val)
    }

    get tenant() { return this._tenant }
    _tenant = null
    set tenant(val) {
        this._tenant = val;
        this._setTenant(val);
    }

    get env() { return this._env }
    _env = null
    set env(val) {
        this._env = val;
        this._setEnv(val);
    }

    get locale() { return this._locale }
    _locale = null
    set locale(val) {
        this._locale = val;
        this._setLocale(val);
    }

    get localizationDictionary() { return this._localizationDictionary }
    _localizationDictionary
    set localizationDictionary(val) {
        var temp = Object.assign({}, val);
        Object.freeze(temp);
        this._localizationDictionary = temp
        this._setLocalizationDictionary(val)
    }

    get requestHeaders() { return this._requestHeaders }
    _requestHeaders
    set requestHeaders(val) {
        var temp = Object.assign({}, val);
        Object.freeze(temp);
        this._requestHeaders = temp
        this._setRequestHeaders(val)
    }

    get customization() { return this._customization }
    _customization = new Customization()
    set customization(val) {
        this._customization = val
        this._customization._apply()
    }

    set videoEncoderCompletion(completion) {
        _setVideoEncoderCompletion(completion)
    }

    get personDatabase() { return this._personDatabase }
    _personDatabase = new PersonDatabase()

    async isInitialized() {
        return await exec("isInitialized", [])
    }

    async initialize(options) {
        var response = await exec("initialize", [options?.config?.toJson()])

        var jsonObject = JSON.parse(response)
        var success = jsonObject["success"]
        var error = jsonObject["error"]

        if (success) await this._onInit()

        return [success, InitException.fromJson(error)]
    }

    deinitialize() {
        exec("deinitialize", [])
    }

    async startFaceCapture(options) {
        _setCameraSwitchCallback(options?.cameraSwitchCallback)
        var response = await exec("startFaceCapture", [options?.config?.toJson()])
        return FaceCaptureResponse.fromJson(JSON.parse(response))
    }

    stopFaceCapture() {
        exec("stopFaceCapture", [])
    }

    async startLiveness(options) {
        _setCameraSwitchCallback(options?.cameraSwitchCallback)
        _setLivenessNotificationCompletion(options?.notificationCompletion)
        var response = await exec("startLiveness", [options?.config?.toJson()])
        return LivenessResponse.fromJson(JSON.parse(response))
    }

    async startEnrollment(config, options) {
        _setCameraSwitchCallback(options?.cameraSwitchCallback)
        _setLivenessNotificationCompletion(options?.notificationCompletion)
        var response = JSON.parse(await exec("startEnrollment", [serializeInterface(config, EnrollmentConfig)]))
        var lr = LivenessResponse.fromJson(response["livenessResponse"]);
        var er = EnrollmentResponse.fromJson(response["enrollmentResponse"]);
        return [lr, er];
    }

    async startVerification(config, options) {
        _setCameraSwitchCallback(options?.cameraSwitchCallback)
        _setLivenessNotificationCompletion(options?.notificationCompletion)
        var response = JSON.parse(await exec("startVerification", [config.toJson()]))
        var lr = LivenessResponse.fromJson(response["livenessResponse"]);
        var er = VerificationResponse.fromJson(response["verificationResponse"]);
        return [lr, er];
    }

    stopLiveness() {
        exec("stopLiveness", [])
    }

    async matchFaces(request, options) {
        var response = await exec("matchFaces", [request.toJson(), options?.config?.toJson()])
        return MatchFacesResponse.fromJson(JSON.parse(response))
    }

    async splitComparedFaces(facesPairs, similarityThreshold) {
        var response = await exec("splitComparedFaces", [facesPairs.map(item => item.toJson()), similarityThreshold])
        return ComparedFacesSplit.fromJson(JSON.parse(response))
    }

    async detectFaces(request) {
        var response = await exec("detectFaces", [request.toJson()])
        return DetectFacesResponse.fromJson(JSON.parse(response))
    }

    async _onInit() {
        this._version = await this._getVersion()
        this._serviceUrl = await this._getServiceUrl()
        this._tenant = await this._getTenant();
        this._env = await this._getEnv();
        this._locale = await this._getLocale();
    }

    async _getVersion() {
        var response = await exec("getVersion", [])
        return FaceSDKVersion.fromJson(JSON.parse(response))
    }

    async _getServiceUrl() {
        return await exec("getServiceUrl", [])
    }

    _setServiceUrl(url) {
        exec("setServiceUrl", [url])
    }

    async _getTenant() {
        return await exec("getTenant", []);
    }

    _setTenant(tenant) {
        exec("setTenant", [tenant]);
    }

    async _getEnv() {
        return await exec("getEnv", []);
    }

    _setEnv(env) {
        exec("setEnv", [env]);
    }

    async _getLocale() {
        return await exec("getLocale", []);
    }

    _setLocale(locale) {
        exec("setLocale", [locale]);
    }

    _setLocalizationDictionary(dictionary) {
        exec("setLocalizationDictionary", [dictionary])
    }

    _setRequestHeaders(dictionary) {
        exec("setRequestHeaders", [dictionary])
    }
}
